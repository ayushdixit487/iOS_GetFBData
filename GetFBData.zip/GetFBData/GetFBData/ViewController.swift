//
//  ViewController.swift
//  GetFBData
//
//  Created by Hence4th on 20/07/17.
//  Copyright © 2017 Hence4th. All rights reserved.
//

import UIKit
import FBSDKCoreKit
import FBSDKLoginKit
import FBSDKShareKit

class ViewController: UIViewController {

    @IBOutlet weak var fbButton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    @IBAction func loginToFB(_ sender: Any) {
        
        view.endEditing(true)
    
        let fbLogin : FBSDKLoginManager = FBSDKLoginManager()
        fbLogin.logIn(withReadPermissions: ["email"], from: self) { (result, err) in
            if(err != nil){
                print("custom fb login failed",err!)
                    return
            }
            if (result?.isCancelled)!{
                return
            }
            self.dataGettingFromFB( fbLogin: fbLogin)
            print(result?.token.tokenString! as Any)
        }
    }
    
    func dataGettingFromFB(fbLogin:FBSDKLoginManager){
        FBSDKGraphRequest(graphPath: "/me", parameters: ["fields":"id, email, first_name, last_name, picture.type(large), gender"]).start { (connection, result, err) in 
            if (err != nil){
                print("failed to start graph request:",err!)
                    return
                }
            
            let fbDetails = result as! NSDictionary
            var email : String? = fbDetails["email"] as? String
            print(email as Any)
                    if(email == nil){
                        email = ""
                }
            let firstName = fbDetails["first_name"] as! String
            print(firstName)
            let gender = fbDetails["gender"] as! String
            print(gender)
            let id = fbDetails["id"] as! String
            print(id)
            let lastName = fbDetails["last_name"] as! String
            print(lastName)
            let url = ((fbDetails["picture"] as! NSDictionary)["data"] as! NSDictionary)["url"] as! String
            print(url)
            // data get here

            fbLogin.logOut()
        }
        }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

